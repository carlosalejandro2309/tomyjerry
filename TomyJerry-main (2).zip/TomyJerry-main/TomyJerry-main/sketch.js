

function preload() {


}

function setup(){
    canvas = createCanvas(1000,800);


}

function draw() {

    background(0);

    drawSprites();
}


function keyPressed(){


}